<?php
// Show all errors (good for development)
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// ✅ Correct DB credentials (from your screenshot)
$host = "sql109.infinityfree.com";
$dbname = "if0_39575310_maochanpha_db1";
$username = "if0_39575310";
$password = "YOUR_CPANEL_PASSWORD"; // ❗ Replace with your real InfinityFree password

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
