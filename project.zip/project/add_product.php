<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit;
}

// Database connection
$conn = new mysqli("localhost", "root", "", "product");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

// Handle form submission for adding product
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['add_product'])) {
    // Sanitize inputs
    $shop = mysqli_real_escape_string($conn, $_POST['shop']);
    $product_code = mysqli_real_escape_string($conn, $_POST['product_code']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $qty = mysqli_real_escape_string($conn, $_POST['qty']);

    if (empty($shop) || empty($product_code) || empty($name) || empty($price) || empty($qty)) {
        $message = "<p class='message error'>❌ Please fill in all required fields.</p>";
    } else {
        // Handle image upload
        $image = "";
        if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
            $targetDir = "uploads/";
            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0777, true);
            }
            $image = $targetDir . basename($_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'], $image);
        }

        // Insert into database
        $sql = "INSERT INTO products (shop_name, product_code, name, price, qty, image) 
                VALUES ('$shop', '$product_code', '$name', '$price', '$qty', '$image')";

        if ($conn->query($sql) === TRUE) {
            $message = "<p class='message success'>✅ New product added for $shop!</p>";
        } else {
            if ($conn->errno == 1062) {
                $message = "<p class='message error'>❌ Product code already exists! Please use a different code.</p>";
            } else {
                $message = "<p class='message error'>❌ Error: " . $conn->error . "</p>";
            }
        }
    }
}

// Handle form submission for removing product
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['remove_product'])) {
    $remove_code = mysqli_real_escape_string($conn, $_POST['remove_product_code']);
    if (!empty($remove_code)) {
        $delete_sql = "DELETE FROM products WHERE product_code = '$remove_code'";
        if ($conn->query($delete_sql) === TRUE) {
            $message = "<p class='message success'>✅ Product $remove_code removed successfully.</p>";
        } else {
            $message = "<p class='message error'>❌ Error removing product: " . $conn->error . "</p>";
        }
    } else {
        $message = "<p class='message error'>❌ Please select a product to remove.</p>";
    }
}

// Fetch all products for remove dropdown
$product_result = $conn->query("SELECT product_code, name, shop_name FROM products ORDER BY shop_name, product_code");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin Panel - Add / Remove Product</title>
    <style>
        /* Your existing styles here (unchanged) */
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #fff8f4;
            color: #333;
            margin: 0;
            padding: 0;
        }
        header {
            background: #ff8a65;
            color: white;
            text-align: center;
            padding: 20px;
            font-size: 1.8rem;
            font-weight: bold;
        }
        .container {
            max-width: 600px;
            background: #fff;
            margin: 50px auto;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #ff6b6b;
        }
        form label {
            display: block;
            text-align: left;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"], 
        input[type="number"], 
        input[type="file"], 
        select {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 1rem;
            transition: border 0.3s ease;
        }
        input:focus, select:focus {
            border-color: #ff8a65;
            outline: none;
        }
        button {
            background: linear-gradient(135deg, #ff9a76, #ff6b6b);
            color: white;
            border: none;
            padding: 14px;
            width: 100%;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.2s;
        }
        button:hover {
            background: linear-gradient(135deg, #ff6b6b, #e74c3c);
            transform: scale(1.03);
        }
        .message {
            text-align: center;
            font-size: 1.1rem;
            margin-bottom: 15px;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #ff6b6b;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }
        .back-link:hover {
            color: #e74c3c;
        }
        /* Separate forms spacing */
        form + form {
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <header>Admin Panel - Manage Products</header>
    <div class="container">

        <?php echo $message; ?>

        <!-- Add Product Form -->
        <h2>Add Product</h2>
        <form method="POST" enctype="multipart/form-data">
            <label for="shop">Select Shop:</label>
            <select name="shop" id="shop" required>
                <option value="">-- Select Shop --</option>
                <option value="Zando">Zando</option>
                <option value="Ten11">Ten11</option>
                <option value="Routine">Routine</option>
            </select>

            <label for="product_code">Product Code:</label>
            <input type="text" name="product_code" id="product_code" required>

            <label for="name">Product Name:</label>
            <input type="text" name="name" id="name" required>

            <label for="price">Price:</label>
            <input type="number" name="price" step="0.01" id="price" required>

            <label for="qty">Quantity:</label>
            <input type="number" name="qty" id="qty" required>

            <label for="image">Product Image:</label>
            <input type="file" name="image" id="image">

            <button type="submit" name="add_product">Add Product</button>
        </form>

        <!-- Remove Product Form -->
        <h2>Remove Product</h2>
        <form method="POST">
            <label for="remove_product_code">Select Product to Remove:</label>
            <select name="remove_product_code" id="remove_product_code" required>
                <option value="">-- Select Product --</option>
                <?php if ($product_result && $product_result->num_rows > 0): ?>
                    <?php while ($prod = $product_result->fetch_assoc()): ?>
                        <option value="<?= htmlspecialchars($prod['product_code']) ?>">
                            <?= htmlspecialchars($prod['shop_name']) ?> - <?= htmlspecialchars($prod['product_code']) ?> - <?= htmlspecialchars($prod['name']) ?>
                        </option>
                    <?php endwhile; ?>
                <?php else: ?>
                    <option value="">No products available</option>
                <?php endif; ?>
            </select>
            <button type="submit" name="remove_product" onclick="return confirm('Are you sure you want to remove this product?');">Remove Product</button>
        </form>

        <a href="admin_dashboard.php" class="back-link">⬅ Back to Dashboard</a>
    </div>
</body>
</html>

<?php
$conn->close();
?>
