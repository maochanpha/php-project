<?php
session_start();
include 'db.php';

// Redirect if not logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Handle Delete One Grade
if (isset($_POST['delete']) && isset($_POST['delete_id'])) {
    $deleteId = (int)$_POST['delete_id'];
    $conn->query("DELETE FROM grades WHERE id = $deleteId");
}

// Handle Clear All Grades
if (isset($_POST['clear'])) {
    $conn->query("DELETE FROM grades");
}

// Handle Add Grade
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_grade'])) {
    $student = $_POST['student_name'];
    $course = $_POST['course'];
    $midterm = (int)$_POST['midterm'];
    $final = (int)$_POST['final'];
    $total = $midterm + $final;

    // Assign letter grade
    if ($total >= 90) $grade = 'A';
    elseif ($total >= 80) $grade = 'B';
    elseif ($total >= 70) $grade = 'C';
    elseif ($total >= 60) $grade = 'D';
    else $grade = 'F';

    $conn->query("INSERT INTO grades (student_name, course, midterm, final, total, letter_grade) 
                VALUES ('$student', '$course', $midterm, $final, $total, '$grade')");
}

// Fetch grades
$grades = $conn->query("SELECT * FROM grades");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Grade Management</title>
    <style>
        input[type=text], input[type=number] {
            padding: 6px;
            margin: 5px 0;
            width: 200px;
        }
        input[type=submit], button {
            padding: 6px 12px;
            margin-top: 10px;
            cursor: pointer;
        }
        table {
            margin-top: 20px;
            border-collapse: collapse;
            width: 100%;
        }
        table, th, td {
            border: 1px solid #999;
        }
        th, td {
            padding: 10px;
        }
        .delete-btn {
            background-color: red;
            color: white;
        }
        .clear-btn {
            background-color: darkred;
            color: white;
        }
    </style>
</head>
<body>

<h2>Grade Entry</h2>
<form method="POST">
    <input name="student_name" placeholder="Student Name" required><br>
    <input name="course" placeholder="Course" required><br>
    <input name="midterm" type="number" placeholder="Midterm Score" required><br>
    <input name="final" type="number" placeholder="Final Score" required><br>
    <input type="submit" name="add_grade" value="Add Grade">
    <button onclick="window.location.href='dashboard.php'">Back to Dashboard</button>
</form>

<!-- Clear All Grades -->
<form method="POST" onsubmit="return confirm('Are you sure you want to clear all grade data?');">
    <input type="submit" name="clear" value="Clear All Grades" class="clear-btn">
</form>

<h3>All Grades</h3>
<table>
    <tr>
        <th>Student</th>
        <th>Course</th>
        <th>Midterm</th>
        <th>Final</th>
        <th>Total</th>
        <th>Grade</th>
        <th>Action</th>
    </tr>
    <?php while($row = $grades->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($row['student_name']) ?></td>
        <td><?= htmlspecialchars($row['course']) ?></td>
        <td><?= $row['midterm'] ?></td>
        <td><?= $row['final'] ?></td>
        <td><?= $row['total'] ?></td>
        <td><?= $row['letter_grade'] ?></td>
        <td>
            <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this grade?');">
                <input type="hidden" name="delete_id" value="<?= $row['id'] ?>">
                <button type="submit" name="delete" class="delete-btn">Delete</button>
            </form>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
