<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user']['id'];

// Add course
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_course'])) {
    $course_name = $_POST['course_name'];
    $course_code = $_POST['course_code'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO courses (user_id, course_name, course_code, description) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $userId, $course_name, $course_code, $description);
    $stmt->execute();
    $stmt->close();
}

// Delete course
if (isset($_POST['delete_id'])) {
    $deleteId = $_POST['delete_id'];
    $conn->query("DELETE FROM courses WHERE id = $deleteId AND user_id = $userId");
}

// Fetch courses
$courses = $conn->query("SELECT * FROM courses WHERE user_id = $userId");
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Courses</title>
    <style>
        body {
            font-family: Arial;
            padding: 20px;
        }
        input, textarea {
            padding: 8px;
            width: 300px;
            margin: 5px 0;
        }
        input[type=submit], button {
            padding: 8px 16px;
            margin-top: 10px;
            cursor: pointer;
        }
        table {
            border-collapse: collapse;
            margin-top: 20px;
            width: 90%;
        }
        th, td {
            border: 1px solid #aaa;
            padding: 10px;
            text-align: left;
        }
        .delete-btn {
            background-color: red;
            color: white;
            border: none;
        }
    </style>
</head>
<body>

<h2>My Courses</h2>

<form method="POST">
    <input type="text" name="course_name" placeholder="Course Name" required><br>
    <input type="text" name="course_code" placeholder="Course Code" required><br>
    <textarea name="description" placeholder="Description (optional)"></textarea><br>
    <input type="submit" name="add_course" value="Add Course">
    <button onclick="window.location.href='dashboard.php'">Back to Dashboard</button>
</form>

<?php if ($courses->num_rows > 0): ?>
    <h3>Course List</h3>
    <table>
        <tr>
            <th>Course Name</th>
            <th>Code</th>
            <th>Description</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $courses->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['course_name']) ?></td>
            <td><?= htmlspecialchars($row['course_code']) ?></td>
            <td><?= htmlspecialchars($row['description']) ?></td>
            <td>
                <form method="POST" onsubmit="return confirm('Delete this course?');">
                    <input type="hidden" name="delete_id" value="<?= $row['id'] ?>">
                    <button type="submit" class="delete-btn">Delete</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p>No courses added yet.</p>
<?php endif; ?>

</body>
</html>
