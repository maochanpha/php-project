<?php
session_start();
include 'db.php';

// Redirect to login if not logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user']; // get current session user
$userId = $user['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $department = $_POST['department'];

    $image = $user['image']; // default image
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        $tmp = $_FILES['image']['tmp_name'];
        move_uploaded_file($tmp, "uploads/" . $image);
    }

    $sql = "UPDATE users SET name='$name', email='$email', department='$department', image='$image' WHERE id=$userId";

    if ($conn->query($sql)) {
        // Update session data
        $_SESSION['user']['name'] = $name;
        $_SESSION['user']['email'] = $email;
        $_SESSION['user']['department'] = $department;
        $_SESSION['user']['image'] = $image;

        echo "Profile updated successfully. <a href='dashboard.php'>Go back to dashboard</a>";
    } else {
        echo "Error updating profile: " . $conn->error;
    }
}
?>
<DOCTYPE html>

    <head>
        <title>Edit Profile</title>
        <style>
            body {
                font-family: 'Segoe UI', sans-serif;
                background: #f7f7f7;
                padding: 40px;
                margin: 0;
            }

            .profile-container {
                max-width: 500px;
                margin: 0 auto;
                background: white;
                padding: 30px;
                border-radius: 12px;
                box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            }

            .profile-container h2 {
                text-align: center;
                margin-bottom: 25px;
                color: #333;
            }

            label {
                display: block;
                margin-bottom: 5px;
                font-weight: 600;
                color: #444;
            }

            input[type="text"],
            input[type="email"],
            input[type="file"],
            select {
                width: 100%;
                padding: 10px;
                margin-bottom: 15px;
                border-radius: 6px;
                border: 1px solid #ccc;
                box-sizing: border-box;
            }

            input[type="submit"] {
                background-color: #ff8c69;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                cursor: pointer;
                width: 100%;
                font-weight: bold;
                transition: background 0.3s;
            }

            input[type="submit"]:hover {
                background-color: #e67c5a;
            }

            .profile-pic-preview {
                text-align: center;
                margin-bottom: 15px;
            }

            .profile-pic-preview img {
                width: 120px;
                height: 120px;
                border-radius: 50%;
                object-fit: cover;
                border: 3px solid #eee;
            }
        </style>

    </head>
    <html>

    <body>
        <h2>Edit Profile</h2>
        <form method="POST" enctype="multipart/form-data">
            <label>Name:</label><br>
            <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required><br><br>

            <label>Email:</label><br>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required><br><br>

            <label>Department:</label><br>
            <input type="text" name="department" value="<?= htmlspecialchars($user['department']) ?>" required><br><br>

            <label>Profile Image:</label><br>
            <input type="file" name="image"><br>
            <img src="uploads/<?= htmlspecialchars($user['image']) ?>" width="100" alt="Profile Image"><br><br>

            <input type="submit" value="Update Profile">
            
        </form>
    </body>

    </html>