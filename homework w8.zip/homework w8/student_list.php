<?php
session_start();

// Start with an empty list
if (!isset($_SESSION['students'])) {
    $_SESSION['students'] = [];
}

// Add student
if (isset($_POST['add'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);

    if (!empty($name) && !empty($email)) {
        $_SESSION['students'][] = ["name" => $name, "email" => $email];
    }
}

// Delete one student
if (isset($_POST['delete']) && isset($_POST['index'])) {
    $index = (int)$_POST['index'];
    if (isset($_SESSION['students'][$index])) {
        array_splice($_SESSION['students'], $index, 1);
    }
}

// Clear all students
if (isset($_POST['clear_all'])) {
    $_SESSION['students'] = [];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            text-align: center;
        }
        .container {
            width: 60%;
            margin: auto;
            margin-top: 50px;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            color: #333;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
        }
        th {
            background: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        .form-group {
            margin-top: 20px;
        }
        input[type="text"], input[type="email"] {
            padding: 10px;
            width: 40%;
            margin: 10px 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            padding: 10px 20px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        .delete-btn {
            background: #dc3545;
        }
        .delete-btn:hover {
            background: #c82333;
        }
        .clear-btn {
            margin-top: 20px;
            background: #6c757d;
        }
        .clear-btn:hover {
            background: #5a6268;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Student List</h2>

        <!-- Add Student Form -->
        <form method="POST" class="form-group">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <button type="submit" name="add">Add Student</button>
            <button onclick="window.location.href='dashboard.php'">Back to Dashboard</button>
        </form>

        <!-- Student Table -->
        <table>
            <tr>
                <th>No.</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
            <?php foreach ($_SESSION['students'] as $index => $student): ?>
                <tr>
                    <td><?= $index + 1 ?></td>
                    <td><?= htmlspecialchars($student['name']) ?></td>
                    <td><?= htmlspecialchars($student['email']) ?></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="index" value="<?= $index ?>">
                            <button type="submit" name="delete" class="delete-btn">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>

        <!-- Clear All Button -->
        <?php if (!empty($_SESSION['students'])): ?>
            <form method="POST">
                <button type="submit" name="clear_all" class="clear-btn">Clear All Students</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
