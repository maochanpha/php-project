<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 50px;
            text-align: center;
        }
        .profile-box {
            background: white;
            border-radius: 10px;
            padding: 30px;
            width: 400px;
            margin: 0 auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
        .profile-box img {
            border-radius: 50%;
            width: 100px;
            height: 100px;
        }
        .profile-box h2 {
            margin-bottom: 5px;
        }
        .profile-box p {
            margin: 5px 0;
        }
        .button-group {
            margin-top: 20px;
        }
        .button-group a {
            padding: 10px 15px;
            margin: 5px;
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
        }
        .button-group a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="profile-box">
    <h2>Welcome, Prof. <?= htmlspecialchars($user['name']) ?></h2>
    <img src="uploads/<?= htmlspecialchars($user['image']) ?>" alt="Profile Image"><br><br>

    <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
    <p><strong>Department:</strong> <?= htmlspecialchars($user['department']) ?></p>

    <div class="button-group">
        <a href="edit_profile.php">Edit Profile</a>
        <a href="my_courses.php">My Courses</a>
        <a href="student_list.php">Student List</a>
        <a href="grade.php">Grade</a>
        <a href="logout.php">Logout</a>
        

    </div>
</div>

</body>
</html>
