<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 50px;
            text-align: center;
        }
        form {
            background: white;
            border-radius: 10px;
            padding: 30px;
            width: 300px;
            margin: 0 auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 50%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        input[type="file"] {
            margin-top: 10px;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        h1 {
            color: #333;
        }
        p {
            color: #666;
        }
        a {
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        input[type="file"] {
            display: block;
            margin: 10px auto;
        }

    </style>
</head>
<body>
    <h1>Register here!</h1>
    <form method="POST" enctype="multipart/form-data">
    <input type="text" name="name" placeholder="Full Name" required><br>
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <input type="text" name="department" placeholder="Department" required><br>
    <input type="file" name="image" required><br>
    <input type="submit" value="Register">
    <p>Already have an account? <a href="login.php">Login here</a></p>
</form>
</body>
</html>

<?php
include 'db.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $img = $_FILES['image']['name'];
    $department = $_POST['department'];

    // Profile picture
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);

    $sql = "INSERT INTO users (name, email, password, department, image) VALUES ('$name', '$email', '$password', '$department', '$img')";
    if ($conn->query($sql)) {
        echo "Registered Successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>