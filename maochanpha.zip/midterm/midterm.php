<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Grading System</title>
</head>

<body>
    <h1>Student Grading System</h1>
    <form action="" method="POST">
        <h2>Enter the student score:</h2>
        <input type="text" name="name" placeholder="Enter name" > <br>
        <input type="number" name="attendance" placeholder="Attendance (0-10)" > <br>
        <input type="number" name="quiz" placeholder="Quiz (0-15)" > <br>
        <input type="number" name="midterm" placeholder="Midterm Exam (0-15)" > <br>
        <input type="number" name="final" placeholder="Final Exam (0-60)" > <br>
        <button type="submit" name="save">Add</button>
        <button type="submit" name="update">Update</button>
        <button type="submit" name="delete">Delete</button>
        <a href="view.php">View</a>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = $_POST['name'];
        $attendance = (int)$_POST['attendance'];
        $quiz = (int)$_POST['quiz'];
        $midterm_score = (int)$_POST['midterm'];
        $final = (int)$_POST['final'];

        $total = $attendance + $quiz + $midterm_score + $final;
        $max_total = 10 + 15 + 15 + 60;
        $average = ($total / $max_total) * 100;

        if ($average >= 90) {
            $grade = 'A';
        } elseif ($average >= 80) {
            $grade = 'B';
        } elseif ($average >= 70) {
            $grade = 'C';
        } elseif ($average >= 60) {
            $grade = 'D';
        } elseif ($average >= 50) {
            $grade = 'E';
        } else {
            $grade = 'F';
        }

        echo "<h2>Student Name: $name</h2>";
        echo "<p>Attendance: $attendance</p>";
        echo "<p>Quiz: $quiz</p>";
        echo "<p>Midterm Exam: $midterm_score</p>";
        echo "<p>Final Exam: $final</p>";
        echo "<p>Total Score: $total</p>";
        echo "<p>Grade: $grade</p>";

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "midterm";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if (isset($_POST['save'])) {
            // Check if student exists
            $check = $conn->prepare("SELECT id FROM midterm WHERE name = ?");
            $check->bind_param("s", $name);
            $check->execute();
            $check->store_result();

            if ($check->num_rows > 0) {
                echo "<div class='error-msg'>❌ Student already exists. Use Update to change the score.</div>";
            } else {
                // Insert new student
                $insert = $conn->prepare("INSERT INTO midterm (name, attendance, quiz, midterm, final, total, grade) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $insert->bind_param("siiiiis", $name, $attendance, $quiz, $midterm_score, $final, $total, $grade);
                if ($insert->execute()) {
                    echo "<p>New record created successfully</p>";
                } else {
                    echo "<p>Error: " . $conn->error . "</p>";
                }
                $insert->close();
            }
            $check->close();
        }

        if (isset($_POST['update'])) {
            // Update existing student
            $update = $conn->prepare("UPDATE midterm SET attendance=?, quiz=?, midterm=?, final=?, total=?, grade=? WHERE name=?");
            $update->bind_param("iiiiiss", $attendance, $quiz, $midterm_score, $final, $total, $grade, $name);
            if ($update->execute() && $update->affected_rows > 0) {
                echo "<div class='success-msg'>✅ Student score updated successfully!</div>";
            } else {
                echo "<div class='error-msg'>❌ No matching student found to update.</div>";
            }
            $update->close();
        }

        $conn->close();
    }
    ?>
</body>
</html>