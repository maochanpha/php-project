<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "midterm";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle clear all data
if (isset($_POST['clear'])) {
    $conn->query("DELETE FROM midterm");
}

// Handle delete single row
if (isset($_POST['delete']) && isset($_POST['delete_id'])) {
    $delete_id = (int)$_POST['delete_id'];
    $conn->query("DELETE FROM midterm WHERE id = $delete_id");
}

// Fetch all records
$sql = "SELECT * FROM midterm";
$result = $conn->query($sql);

// Count occurrences of each name for duplicate highlighting
$name_counts = [];
if ($result && $result->num_rows > 0) {
    foreach ($result as $row) {
        $n = $row['name'];
        if (!isset($name_counts[$n])) $name_counts[$n] = 0;
        $name_counts[$n]++;
    }
    // Reset result pointer for fetch_assoc()
    $result->data_seek(0);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Scores</title>
</head>
<body>
    <h1>All Student Scores</h1>
    <form method="post" style="margin-bottom: 20px;">
        <button type="submit" name="clear" onclick="return confirm('Are you sure you want to delete all records?');">
            Clear All Data
        </button>
    </form>
    <table border="1" cellpadding="8" cellspacing="0">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Attendance</th>
            <th>Quiz</th>
            <th>Midterm</th>
            <th>Final</th>
            <th>Total</th>
            <th>Grade</th>
            <th>Delete</th>
        </tr>
        <?php
        $no = 1;
        if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td>
                        <?= htmlspecialchars($row['name']) ?>
                        <?php if ($name_counts[$row['name']] > 1): ?>
                            <span style="color:red;font-weight:bold;">(Duplicate)</span>
                        <?php endif; ?>
                    </td>
                    <td><?= $row['attendance'] ?></td>
                    <td><?= $row['quiz'] ?></td>
                    <td><?= $row['midterm'] ?></td>
                    <td><?= $row['final'] ?></td>
                    <td><?= $row['total'] ?></td>
                    <td><?= $row['grade'] ?></td>
                    <td>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="delete_id" value="<?= $row['id'] ?>">
                            <button type="submit" name="delete" onclick="return confirm('Delete this record?');">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="9">No records found.</td>
            </tr>
        <?php endif; ?>
    </table>
    <br>
    <a href="midterm.php">Back to Entry</a>
</body>
</html>
<?php
$conn->close();
?>  